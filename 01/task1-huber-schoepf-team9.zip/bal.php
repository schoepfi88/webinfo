<!DOCTYPE html>
<html>
<head>
<title>Balthazar</title>
<link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="css/theme.css">
<script language="javascript" type="text/javascript" src="script/control.js"></script>
</head>
<body>

<h1 id="header2">Balthasar</h1>
<table id="table">
	<tr>
		<td id="name1">Balthasar</td>
  	</tr>
  	<tr>
  		<td>Huber</td>
  	</tr>
  	<tr>
  		<td>Informatik</td>
  	</tr>
</table>
<p>
<table id="table">
  	<tr> 
  		<td><button onclick="backOverview()">Back to Overview</button></td>
  		<td><button onclick="fanbal()">Become a fan</button></td>
	</tr>
</table>

</body>
</html>
