function bal() {
	window.location.href = "http://localhost/bal.php";
}

function chri() {
	window.location.href = "http://localhost/chri.php";
}

function backOverview() {
	window.location.href = "http://localhost/";
}

function fanbal() {
	alert("You are now a fan from Balthazar");
}

function fanchr() {
	alert("You are now a fan from Christoph");
}