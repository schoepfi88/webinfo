<!DOCTYPE html>
<html>
<head>
<title>Christoph</title>
<link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="css/theme.css">
<script language="javascript" type="text/javascript" src="script/control.js"></script>
</head>
<body>

<h1 id="header2">Christoph</h1>
<table id="table">
	<tr>
		<td id="name1">Christoph</td>
  	</tr>
  	<tr>
  		<td>Schöpf</td>
  	</tr>
  	<tr>
  		<td>Informatik</td>
  	</tr>
</table>
<p>
<table id="table">
  	<tr> 
  		<td><button onclick="backOverview()">Back to Overview</button></td>
  		<td><button onclick="fanchr()">Become a fan</button></td>
	</tr>
</table>

</body>
</html>
