httpd.conf -> /etc/httpd/conf
ssl.conf -> /etc/httpd/conf.d
php.conf -> /etc/httpd/conf.d

server.crt -> /etc/pki/tls/certs
server.csr -> /etc/pki/tls/private
server.key -> /etc/pki/tls/private
