function delete1() {
	console.log("test");
	
}