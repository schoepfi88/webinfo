<?php
	$servername = "localhost";
	$username = "root";
	$password = "password";
	$dbname = "blog";
?>