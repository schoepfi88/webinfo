<?php
session_start();// Starting Session
?>