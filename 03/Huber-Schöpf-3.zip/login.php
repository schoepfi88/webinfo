<?php
session_start();// Starting Session
$_SESSION["loggedin"] = false; 
?>