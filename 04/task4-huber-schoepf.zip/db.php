<?php
	$servername = "localhost";
	$username = "blog";
	$password = "team9";
	$dbname = "blog";
?>